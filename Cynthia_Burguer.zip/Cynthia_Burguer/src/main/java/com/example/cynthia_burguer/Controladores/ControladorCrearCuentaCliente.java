package com.example.cynthia_burguer.Controladores;

import com.example.cynthia_burguer.Elementos.ControladorClaroOscuro;
import com.example.cynthia_burguer.Elementos.Pantallas;
import com.example.cynthia_burguer.Elementos.SentenciasSql;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;

import static com.example.cynthia_burguer.Elementos.Pantallas.mostrarAlerta;

public class ControladorCrearCuentaCliente {
    public TextField CrearUsuario;
    public Button CuentaBoton;
    public TextField CrearPass;
    public Button ClaroOscuro;
    public AnchorPane Fondo;

    @FXML
    protected void initialize() {


        Platform.runLater(() -> {
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);

        });

    }


    public void crear(ActionEvent actionEvent) {
        try {
            String nombreUsuario = CrearUsuario.getText();
            String contraseña = CrearPass.getText();

            if (nombreUsuario.isEmpty() || contraseña.isEmpty()) {
                mostrarAlerta("Error", "Campos Vacíos", "Por favor, complete todos los campos.");
                return; // Salir del método si hay campos vacíos
            }

            Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/InicioDeSesionCliente.fxml", "Inicio de sesión Cliente");
            SentenciasSql.InsertarCliente(nombreUsuario, contraseña);
            Pantallas.cerrarVentana(CuentaBoton);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public void Volver(ActionEvent actionEvent) {
        try {
            Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/InicioDeSesionCliente.fxml","Inicio de sesión Cliente");
            Pantallas.cerrarVentana(CuentaBoton);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void llamarcambiarClaroOscuro(ActionEvent actionEvent) {

        ControladorClaroOscuro.llamarcambiarClaroOscuro(ClaroOscuro,Fondo);
    }
}
