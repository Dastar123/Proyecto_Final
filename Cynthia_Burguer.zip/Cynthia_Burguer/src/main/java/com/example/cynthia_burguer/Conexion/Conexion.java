package com.example.cynthia_burguer.Conexion;


import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase que gestiona la conexión a la base de datos PostgreSQL.
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {

    public String url = "jdbc:mysql://localhost:3306/CynthiaHamburguer";
    public String usuario = "root";
    public String password = ""; // Deja la contraseña vacía si no tienes una configurada
    public static Connection con;

    /**
     * Establece la conexión a la base de datos.
     *
     * @return La conexión establecida.
     */
    public Connection conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, usuario, password);
            if (con != null) {
                System.out.println("Conectado");
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }

    /**
     * Realiza una prueba simple ejecutando una consulta en la base de datos.
     */


    /**
     * Cierra la conexión a la base de datos.
     */
    public void desconectar() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("Desconectado");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


}
