package com.example.cynthia_burguer.Elementos;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Objects;
import java.util.Optional;

public class Pantallas {

    public static void CambiarPantalla(String ruta,String titulo) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Pantallas.class.getResource(ruta));
        Parent root = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle(titulo);
        stage.setScene(new Scene(root));
        stage.show();

    }
    public static  void cerrarVentana(Button Boton) {

        Stage stage = (Stage) Boton.getScene().getWindow();


        stage.close();
    }
    public static void mostrarAlerta(String tipo, String titulo, String contenido) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(tipo);
        alert.setHeaderText(titulo);
        alert.setContentText(contenido);
        alert.showAndWait();
    }

    public static Optional<ButtonType> mostrarAlertaConRespuesta(String tipo, String titulo, String contenido) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(tipo);
        alert.setHeaderText(titulo);
        alert.setContentText(contenido);
        return alert.showAndWait();
    }
    public static void addImage(Pane pane, String ruta, double ancho, double alto) {
        // Comprobar si la ruta de la imagen existe
        File archivo = new File(ruta);
        if (archivo.exists()) {
            System.out.println("La ruta de la imagen existe: " + ruta);
            // Aquí puedes cargar la imagen en el pane
            Image imagen = new Image("file:" + ruta);
            ImageView imageView = new ImageView(imagen);
             imageView.setFitWidth(ancho);
             imageView.setFitHeight(alto);
             pane.getChildren().add(imageView);
        } else {
            System.out.println("La ruta de la imagen no existe: " + ruta);
        }
    }
    public static String conversorRutaRelativa(String ruta){
        String rutaRelativa = Paths.get("src", "main", "resources", "imgs", ruta).toString();

        return rutaRelativa;
    }
    public static void agregarDetallePedido(ObservableList<DetallePedido> detalles, Spinner<Integer> spinner, Label precioLabel, Label menuLabel) {
        int cantidad = spinner.getValue();
        if (cantidad > 0) {
            String nombre = menuLabel.getText();
            double precio = obtenerPrecioNumerico(precioLabel.getText());
            double total = cantidad * precio;
            detalles.add(new DetallePedido(nombre, precio, cantidad, total));
        }
    }

    private static double obtenerPrecioNumerico(String precioConSimbolo) {
        // Eliminar el símbolo "€" y los espacios en blanco, luego convertir a double
        String precioNumerico = precioConSimbolo.replaceAll("[^\\d.,]", "");
        // Reemplazar las comas por puntos para tener un formato consistente
        precioNumerico = precioNumerico.replace(',', '.');

        // Convertir a double
        return Double.parseDouble(precioNumerico);
    }
}
