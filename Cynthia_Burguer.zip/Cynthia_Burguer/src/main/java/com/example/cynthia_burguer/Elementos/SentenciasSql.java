package com.example.cynthia_burguer.Elementos;

import com.example.cynthia_burguer.Conexion.Conexion;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

import static com.example.cynthia_burguer.Elementos.Pantallas.mostrarAlerta;

public class SentenciasSql {


    // Sentencia SQL para insertar un nuevo cliente
    public static final String INSERTAR_CLIENTE = "INSERT INTO ClientesRegistrados (nombre_usuario, contraseña) VALUES (?, ?)";

    // Método para insertar un nuevo cliente
    public static void InsertarCliente(String nombreUsuario, String contraseña) {
        Conexion conexion = new Conexion();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establecer la conexión a la base de datos
            connection = conexion.conectar();

            // Verificar si el nombre de usuario ya existe
            String verificarUsuarioQuery = "SELECT * FROM ClientesRegistrados WHERE nombre_usuario = ?";
            preparedStatement = connection.prepareStatement(verificarUsuarioQuery);
            preparedStatement.setString(1, nombreUsuario);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // El nombre de usuario ya existe, mostrar alerta
                mostrarAlerta("Error", "Nombre de usuario duplicado", "El nombre de usuario ya está siendo utilizado.");
            } else {
                // Preparar la sentencia SQL para insertar el cliente
                preparedStatement = connection.prepareStatement(INSERTAR_CLIENTE);
                preparedStatement.setString(1, nombreUsuario);
                preparedStatement.setString(2, contraseña);

                // Ejecutar la sentencia SQL
                int filasAfectadas = preparedStatement.executeUpdate();

                if (filasAfectadas > 0) {
                    System.out.println("Cliente insertado correctamente.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Mostrar alerta en caso de error de SQL
            mostrarAlerta("Error", "Error de base de datos", "Ha ocurrido un error al insertar el cliente.");
        } finally {
            // Cerrar la conexión y los statement
            conexion.desconectar();
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            conexion.desconectar();
        }
    }
    public static boolean verificarCredencialesCliente(String nombreUsuario, String contraseña) {
        Conexion conexion = new Conexion();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establecer la conexión a la base de datos
            connection = conexion.conectar();

            // Preparar la sentencia SQL para verificar las credenciales del cliente
            String verificarCredencialesQuery = "SELECT * FROM ClientesRegistrados WHERE nombre_usuario = ? AND contraseña = ?";
            preparedStatement = connection.prepareStatement(verificarCredencialesQuery);
            preparedStatement.setString(1, nombreUsuario);
            preparedStatement.setString(2, contraseña);
            resultSet = preparedStatement.executeQuery();

            // Si el conjunto de resultados tiene al menos una fila, las credenciales son válidas
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            // En caso de error, retornar false
            return false;
        } finally {
            // Cerrar la conexión y los statement
            conexion.desconectar();
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
           conexion.desconectar();
        }
    }

    public static void InsertarAdmin(String nombreCuenta, String contraseña) {
        Conexion conexion = new Conexion();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establecer la conexión a la base de datos
            connection = conexion.conectar();

            // Verificar si el nombre de cuenta ya existe
            String verificarAdminQuery = "SELECT * FROM Administrador WHERE nombre_cuenta = ?";
            preparedStatement = connection.prepareStatement(verificarAdminQuery);
            preparedStatement.setString(1, nombreCuenta);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // El nombre de cuenta ya existe, mostrar alerta
                mostrarAlerta("Error", "Nombre de cuenta duplicado", "El nombre de cuenta ya está siendo utilizado.");
            } else {
                // Preparar la sentencia SQL para insertar el admin
                String INSERTAR_ADMIN = "INSERT INTO Administrador (nombre_cuenta, contraseña) VALUES (?, ?)";
                preparedStatement = connection.prepareStatement(INSERTAR_ADMIN);
                preparedStatement.setString(1, nombreCuenta);
                preparedStatement.setString(2, contraseña);

                // Ejecutar la sentencia SQL
                int filasAfectadas = preparedStatement.executeUpdate();

                if (filasAfectadas > 0) {
                    System.out.println("Admin insertado correctamente.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Mostrar alerta en caso de error de SQL
            mostrarAlerta("Error", "Error de base de datos", "Ha ocurrido un error al insertar el administrador.");
        } finally {
            // Cerrar la conexión y los statement
            conexion.desconectar();
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
          conexion.desconectar();
        }
    }
    public static boolean verificarCredencialesAdmin(String nombreCuenta, String contraseña) {
        Conexion conexion = new Conexion();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establecer la conexión a la base de datos
            connection = conexion.conectar();

            // Preparar la sentencia SQL para verificar las credenciales del administrador
            String verificarCredencialesQuery = "SELECT * FROM Administrador WHERE nombre_cuenta = ? AND contraseña = ?";
            preparedStatement = connection.prepareStatement(verificarCredencialesQuery);
            preparedStatement.setString(1, nombreCuenta);
            preparedStatement.setString(2, contraseña);
            resultSet = preparedStatement.executeQuery();

            // Si el conjunto de resultados tiene al menos una fila, las credenciales son válidas
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            // En caso de error, retornar false
            return false;
        } finally {
            // Cerrar la conexión y los statement
            conexion.desconectar();
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
          conexion.desconectar();
        }
    }

    public static String obtenerNombreYPrecioProductos(String tipoBusqueda, int numero) {
        Conexion conexion = new Conexion();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String resultado = null;

        try {
            // Establecer la conexión a la base de datos
            connection = conexion.conectar();

            // Preparar la sentencia SQL para obtener el nombre y el precio de todos los productos
            String query;
            switch (tipoBusqueda) {
                case "nombre":
                    query = "SELECT nombre FROM Productos WHERE id = ?";
                    break;
                case "precio":
                    query = "SELECT precio FROM Productos WHERE id = ?";
                    break;
                default:
                    throw new IllegalArgumentException("Tipo de búsqueda no válido: " + tipoBusqueda);
            }
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, numero);
            resultSet = preparedStatement.executeQuery();

            // Verificar si se encontró un resultado
            if (resultSet.next()) {
                resultado = resultSet.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar la conexión y los statement
            conexion.desconectar();
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return resultado;
    }
    // Variable estática para el insert into de Pedidos
    public static final String INSERTAR_PEDIDO = "INSERT INTO Pedidos (precio_total, fecha) VALUES (?, NOW())";

    // Método estático para insertar un nuevo pedido
    public static void insertarPedido(float precioTotal) {
        Conexion conexion = new Conexion();
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establecer la conexión a la base de datos
            connection = conexion.conectar();

            // Preparar la sentencia SQL para insertar el pedido
            preparedStatement = connection.prepareStatement(INSERTAR_PEDIDO);
            preparedStatement.setFloat(1, precioTotal);

            // Ejecutar la sentencia SQL
            int filasAfectadas = preparedStatement.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Pedido insertado correctamente.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Mostrar alerta en caso de error de SQL
            mostrarAlerta("Error", "Error de base de datos", "Ha ocurrido un error al insertar el pedido.");
        } finally {
            // Cerrar la conexión y los statement
            conexion.desconectar();
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static ObservableList<Pedido> obtenerPedidos() {
        ObservableList<Pedido> pedidos = FXCollections.observableArrayList();
        Conexion conexion = new Conexion();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establecer la conexión a la base de datos
            connection = conexion.conectar();

            // Preparar la sentencia SQL para seleccionar todos los pedidos
            String sql = "SELECT id, DATE_FORMAT(fecha, '%d/%m/%Y') AS fecha, precio_total FROM Pedidos";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            // Recorrer los resultados y cargarlos en la lista de pedidos
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String fecha = resultSet.getString("fecha");
                float precioTotal = resultSet.getFloat("precio_total");
                pedidos.add(new Pedido(id, fecha, precioTotal));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Mostrar alerta en caso de error de SQL
            mostrarAlerta("Error", "Error de base de datos", "Ha ocurrido un error al cargar los pedidos.");
        } finally {
            // Cerrar la conexión y los statement
            conexion.desconectar();
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return pedidos;
    }
    public static void eliminarPedidos(int id) {
        Conexion conexion = new Conexion();
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establecer la conexión a la base de datos
            connection = conexion.conectar();

            // Preparar la sentencia SQL para eliminar el pedido específico por su ID
            String sql = "DELETE FROM Pedidos WHERE id = ?";
            preparedStatement = connection.prepareStatement(sql);

            // Establecer el valor del parámetro ID en la sentencia SQL
            preparedStatement.setInt(1, id);

            // Ejecutar la sentencia SQL para eliminar el pedido específico
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Mostrar alerta en caso de error de SQL
            mostrarAlerta("Error", "Error de base de datos", "Ha ocurrido un error al eliminar el pedido.");
        } finally {
            // Cerrar la conexión y los statement
            conexion.desconectar();
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }


}