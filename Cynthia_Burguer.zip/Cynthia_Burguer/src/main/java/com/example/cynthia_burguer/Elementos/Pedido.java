package com.example.cynthia_burguer.Elementos;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.FloatProperty;
import javafx.beans.property.SimpleFloatProperty;

public class Pedido {
    private final IntegerProperty id;
    private final StringProperty fecha;
    private final FloatProperty precioTotal;

    public Pedido(int id, String fecha, float precioTotal) {
        this.id = new SimpleIntegerProperty(id);
        this.fecha = new SimpleStringProperty(fecha);
        this.precioTotal = new SimpleFloatProperty(precioTotal);
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public StringProperty fechaProperty() {
        return fecha;
    }

    public FloatProperty precioTotalProperty() {
        return precioTotal;
    }

    public int getId() {
        return id.get();
    }

    public String getFecha() {
        return fecha.get();
    }

    public float getPrecioTotal() {
        return precioTotal.get();
    }
}
