package com.example.cynthia_burguer.Controladores;

import com.example.cynthia_burguer.Elementos.ControladorClaroOscuro;
import com.example.cynthia_burguer.Elementos.Pantallas;
import com.example.cynthia_burguer.Elementos.Pedido;
import com.example.cynthia_burguer.Elementos.SentenciasSql;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.scene.control.*;

import java.io.IOException;
import java.util.Optional;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;


public class ControladorGestionDeClientes {

    public TextField Buscador;
    public CheckBox PedidoChekBox;
    public CheckBox PrecioCheckBox;

    public CheckBox FechaChekBox;
    @FXML
    private TableView<Pedido> ListaDePedidos;

    @FXML
    private TableColumn<Pedido, Integer> IdColumna;

    @FXML
    private TableColumn<Pedido, String> FechaColumna;

    @FXML
    private TableColumn<Pedido, String> PrecioTotalColumna;

    @FXML
    private Button CerrarSesionBoton;

    private ObservableList<Pedido> listaOriginalDePedidos;
    public Button ClaroOscuro;
    public AnchorPane Fondo;


    @FXML
    private void initialize() {
        cargarPedidos();
        configurarBuscador();
        Platform.runLater(() -> {
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);

        });
        PedidoChekBox.setOnAction(event -> actualizarBusqueda());
        FechaChekBox.setOnAction(event -> actualizarBusqueda());
        PrecioCheckBox.setOnAction(event -> actualizarBusqueda());
    }

    private void cargarPedidos() {
        IdColumna.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        FechaColumna.setCellValueFactory(cellData -> cellData.getValue().fechaProperty());

        // Ajustar el contenido de PrecioTotalColumna y agregar el símbolo del euro
        PrecioTotalColumna.setCellValueFactory(cellData -> {
            Float precio = cellData.getValue().getPrecioTotal();
            String precioConEuro = agregarSimboloEuro(precio);
            return new SimpleStringProperty(precioConEuro);
        });

        // Centrar texto en las columnas
        IdColumna.setStyle("-fx-alignment: CENTER;");
        FechaColumna.setStyle("-fx-alignment: CENTER;");
        PrecioTotalColumna.setStyle("-fx-alignment: CENTER;");

        // Guardar la lista original de pedidos sin filtrar
        listaOriginalDePedidos = SentenciasSql.obtenerPedidos();
        ListaDePedidos.setItems(listaOriginalDePedidos);
    }


    public void CompletarCompra(ActionEvent actionEvent) {
        // Obtener el pedido seleccionado en la tabla
        Pedido pedidoSeleccionado = ListaDePedidos.getSelectionModel().getSelectedItem();

        // Verificar si se ha seleccionado un pedido
        if (pedidoSeleccionado != null) {
            // Mostrar confirmación para confirmar la eliminación
            Optional<ButtonType> result = Pantallas.mostrarAlertaConRespuesta("Confirmar eliminación", "¿Está seguro de que desea eliminar este pedido?", "Esta acción no se puede deshacer");
            if (result.isPresent() && result.get() == ButtonType.OK) {
                // Eliminar el pedido seleccionado
                SentenciasSql.eliminarPedidos(pedidoSeleccionado.getId());
                // Recargar la lista de pedidos
                cargarPedidos();
            }
        } else {
            // Mostrar alerta si no se ha seleccionado ningún pedido
            Pantallas.mostrarAlerta("Warning", "Seleccionar pedido", "No se ha seleccionado ningún pedido. Por favor, seleccione un pedido para completar la compra.");
        }
    }

    public void CerrarSesion(ActionEvent actionEvent) {
        try {
            Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/Inicio.fxml","Inicio");
            Pantallas.cerrarVentana(CerrarSesionBoton);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    private String agregarSimboloEuro(Float precio) {
        return String.format("%.2f €", precio);
    }

    private void configurarBuscador() {
        // Obtener la lista de pedidos de la tabla
        FilteredList<Pedido> listaFiltrada = new FilteredList<>(ListaDePedidos.getItems(), p -> true);

        // Agregar un listener al texto del buscador para filtrar la lista
        Buscador.textProperty().addListener((observable, oldValue, newValue) -> {
            listaFiltrada.setPredicate(pedido -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true; // Si el texto está vacío, mostrar todos los pedidos
                }

                // Convertir el valor del buscador a minúsculas para la comparación sin distinción entre mayúsculas y minúsculas
                String textoBusqueda = newValue.toLowerCase();

                // Verificar si el ID, la fecha o el precio contienen el texto de búsqueda
                boolean buscarPorPedido = PedidoChekBox.isSelected();
                boolean buscarPorFecha = FechaChekBox.isSelected();
                boolean buscarPorPrecio = PrecioCheckBox.isSelected();

                if ((buscarPorPedido && String.valueOf(pedido.getId()).toLowerCase().contains(textoBusqueda))
                        || (buscarPorFecha && pedido.getFecha().toLowerCase().contains(textoBusqueda))
                        || (buscarPorPrecio && String.valueOf(pedido.getPrecioTotal()).toLowerCase().contains(textoBusqueda))) {
                    return true;
                }

                return false; // No coincide con ningún criterio de búsqueda
            });
        });

        // Crear una lista ordenada y filtrada para mostrar los resultados en la tabla
        SortedList<Pedido> listaOrdenada = new SortedList<>(listaFiltrada);
        listaOrdenada.comparatorProperty().bind(ListaDePedidos.comparatorProperty());
        ListaDePedidos.setItems(listaOrdenada);
    }


    private void actualizarBusqueda() {
        // Obtener la lista de pedidos de la tabla
        FilteredList<Pedido> listaFiltrada = new FilteredList<>(listaOriginalDePedidos);

        // Agregar un listener al texto del buscador para filtrar la lista
        Buscador.textProperty().addListener((observable, oldValue, newValue) -> {
            listaFiltrada.setPredicate(pedido -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true; // Si el texto está vacío, mostrar todos los pedidos
                }

                // Convertir el valor del buscador a minúsculas para la comparación sin distinción entre mayúsculas y minúsculas
                String textoBusqueda = newValue.toLowerCase();

                // Verificar si el ID, la fecha o el precio contienen el texto de búsqueda
                boolean coincidePedido = PedidoChekBox.isSelected() && String.valueOf(pedido.getId()).toLowerCase().contains(textoBusqueda);
                boolean coincideFecha = FechaChekBox.isSelected() && pedido.getFecha().toLowerCase().contains(textoBusqueda);
                boolean coincidePrecio = PrecioCheckBox.isSelected() && String.valueOf(pedido.getPrecioTotal()).toLowerCase().contains(textoBusqueda);

                // Retornar verdadero si coincide al menos en uno de los campos seleccionados
                return coincidePedido || coincideFecha || coincidePrecio;
            });
        });

        // Crear una lista ordenada y filtrada para mostrar los resultados en la tabla
        SortedList<Pedido> listaOrdenada = new SortedList<>(listaFiltrada);
        listaOrdenada.comparatorProperty().bind(ListaDePedidos.comparatorProperty());
        ListaDePedidos.setItems(listaOrdenada);
    }


    public void llamarcambiarClaroOscuro(ActionEvent actionEvent) {

        ControladorClaroOscuro.llamarcambiarClaroOscuro(ClaroOscuro,Fondo);

    }
}
