package com.example.cynthia_burguer.Elementos;

import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class ControladorClaroOscuro {

    public static boolean nochedia=true;

    public static void crearImagenes(Button button, AnchorPane fondo, boolean boleannochedia) {

        if (nochedia) {
            Image lunaImage = new Image(ControladorClaroOscuro.class.getResourceAsStream("/imgs/luna.png"));
            ImageView lunaImageView = new ImageView(lunaImage);
            lunaImageView.setFitWidth(30);
            lunaImageView.setFitHeight(30);
            button.setGraphic(lunaImageView);
            cambiarClaroOscuro(fondo,boleannochedia);
        } else {
            Image solImage = new Image(ControladorClaroOscuro.class.getResourceAsStream("/imgs/sol.png"));
            ImageView solImageView = new ImageView(solImage);
            solImageView.setFitWidth(30);
            solImageView.setFitHeight(30);
            button.setGraphic(solImageView);
            cambiarClaroOscuro(fondo,boleannochedia);
        }
    }
    /**
     * Método estático que cambia entre los modos claro y oscuro del estilo del fondo.
     *
     * @param fondo Panel al que se le cambiará el estilo.
     */
    public static void cambiarClaroOscuro( AnchorPane fondo,boolean BoleananocheDia) {
        try {
            Scene scene = fondo.getScene();

            if (scene != null) {
                String cssOscuro =ControladorClaroOscuro .class.getResource("/styles/style_night.css").toExternalForm();
                String cssClaro = ControladorClaroOscuro.class.getResource("/styles/style_day.css").toExternalForm();

                if (BoleananocheDia) {
                    scene.getStylesheets().clear();
                    scene.getStylesheets().add(cssClaro);
                    nochedia=false;



                } else {
                    scene.getStylesheets().clear();
                    scene.getStylesheets().add(cssOscuro);

                    nochedia=true;

                }
            } else {

            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean isModoNocturno() {
        return nochedia;
    }
    public static boolean cambiarEstadoNocheDia(boolean cambio ) {
        nochedia=cambio;
        return nochedia;
    }
    public static void actualizarEstiloNocturno(Button botonClaroOscuro, AnchorPane Fondo) {
        ControladorClaroOscuro.crearImagenes(botonClaroOscuro, Fondo, ControladorClaroOscuro.isModoNocturno());


    }

    public static void llamarcambiarClaroOscuro(Button botonClaroOscuro, AnchorPane Fondo) {
        ControladorClaroOscuro.crearImagenes(botonClaroOscuro, Fondo, ControladorClaroOscuro.cambiarEstadoNocheDia(ControladorClaroOscuro.nochedia));
    }

public static  void CambiarImagen( AnchorPane fondo, String imagenClara,String imagenOscura,Button bottonAcambiar,int ancho,int largo){

    try {
        Scene scene = fondo.getScene();

        if (scene != null) {


            if (ControladorClaroOscuro.nochedia==false) {

                Image ImagenClara = new Image(ControladorClaroOscuro.class.getResourceAsStream(imagenClara));
                ImageView ImagenClaraView = new ImageView(ImagenClara);
                ImagenClaraView.setFitWidth(ancho);
                ImagenClaraView.setFitHeight(largo);
                bottonAcambiar.setGraphic(ImagenClaraView);


            } else {
                Image ImagenOscura = new Image(ControladorClaroOscuro.class.getResourceAsStream(imagenOscura));
                ImageView ImagenOscuraView = new ImageView(ImagenOscura);
                ImagenOscuraView.setFitWidth(ancho);
                ImagenOscuraView.setFitHeight(largo);
                bottonAcambiar.setGraphic(ImagenOscuraView);

            }
        }
    } catch (Exception e) {
        throw new RuntimeException(e);
    }
}
}

