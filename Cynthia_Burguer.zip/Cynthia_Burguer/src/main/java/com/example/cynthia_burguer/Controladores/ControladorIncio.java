package com.example.cynthia_burguer.Controladores;

import com.example.cynthia_burguer.Elementos.ControladorClaroOscuro;
import com.example.cynthia_burguer.Elementos.Pantallas;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;


import java.io.IOException;

public class ControladorIncio {


    public Button BotonPedido;
    public Button ClaroOscuro;
    public AnchorPane Fondo;
    public Button Sesion;

    @FXML
    protected void initialize() {


        Platform.runLater(() -> {
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);
            ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/engranajeOscuro.png",    "/imgs/engranajeClaro.png",Sesion,40,40);
            ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/engranajeOscuro.png",    "/imgs/engranajeClaro.png",Sesion,40,40);
            ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/CarritoClaro.png",   "/imgs/CarritoOscuro.png",BotonPedido,288,181);
            ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/CarritoClaro.png",   "/imgs/CarritoOscuro.png",BotonPedido,288,181);

        });

    }


    @FXML
    protected void HacerPedido() {
        try {
            Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/PantallaDeCompras.fxml","Pedidos");
            Pantallas.cerrarVentana(BotonPedido);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    protected void IncioSesion() {
        try {
            Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/clienteOadmin.fxml","Iniciar Sesión");
            Pantallas.cerrarVentana(BotonPedido);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void llamarcambiarClaroOscuro(ActionEvent actionEvent) {
        ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/engranajeClaro.png","/imgs/engranajeOscuro.png",Sesion,40,40);

        ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/CarritoOscuro.png",   "/imgs/CarritoClaro.png",BotonPedido,288,181);

        ControladorClaroOscuro.llamarcambiarClaroOscuro(ClaroOscuro,Fondo);

    }
}