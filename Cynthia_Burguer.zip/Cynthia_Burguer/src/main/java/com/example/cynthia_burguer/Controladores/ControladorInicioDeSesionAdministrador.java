package com.example.cynthia_burguer.Controladores;

import com.example.cynthia_burguer.Elementos.ControladorClaroOscuro;
import com.example.cynthia_burguer.Elementos.Pantallas;
import com.example.cynthia_burguer.Elementos.SentenciasSql;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;

public class ControladorInicioDeSesionAdministrador {
    public Button EntrarButton;
    public TextField NombreField;
    public TextField contraField;
    public Button ClaroOscuro;
    public AnchorPane Fondo;
    @FXML
    protected void initialize() {


        Platform.runLater(() -> {
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);

        });

    }
    public void CrearCuenta(ActionEvent actionEvent) {
        try {
            Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/CrearCuentaAdmin.fxml","Crear Cuenta de Admin");
            Pantallas.cerrarVentana(EntrarButton);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void Login(ActionEvent actionEvent) {
        try {
            if(SentenciasSql.verificarCredencialesAdmin(NombreField.getText(),contraField.getText())==true){
                Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/GestionDeClientes.fxml","Gestión de Clientes");
                Pantallas.cerrarVentana(EntrarButton);
            }
            else {
                Pantallas.mostrarAlerta("Error", "Error", "No existe ese nombre de usuario o contraseña en la base de datos");
            }
            
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void llamarcambiarClaroOscuro(ActionEvent actionEvent) {

        ControladorClaroOscuro.llamarcambiarClaroOscuro(ClaroOscuro,Fondo);
    }
}
