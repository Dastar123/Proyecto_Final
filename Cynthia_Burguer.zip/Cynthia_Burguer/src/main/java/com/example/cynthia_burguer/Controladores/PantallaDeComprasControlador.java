package com.example.cynthia_burguer.Controladores;

import com.example.cynthia_burguer.Elementos.ControladorClaroOscuro;
import com.example.cynthia_burguer.Elementos.DetallePedido;
import com.example.cynthia_burguer.Elementos.Pantallas;
import com.example.cynthia_burguer.Elementos.SentenciasSql;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;

import java.io.IOException;
import java.net.URL;

import java.nio.file.Paths;
import java.util.ResourceBundle;

public class PantallaDeComprasControlador implements Initializable {

    public Pane imagen1;
    public Pane imagen2;
    public Pane imagen3;
    public Pane imagen4;
    public Pane imagen5;
    public Pane imagen6;
    public Pane imagen7;
    public Pane imagen8;
    public Pane imagen9;
    public Pane imagen10;
    public Pane imagen11;
    public Pane imagen12;

    public Spinner spinner1;
    public Spinner spinner2;
    public Spinner spinner3;
    public Spinner spinner4;
    public Spinner spinner5;
    public Spinner spinner6;
    public Spinner spinner7;
    public Spinner spinner8;
    public Spinner spinner9;
    public Spinner spinner10;
    public Spinner spinner11;
    public Spinner spinner12;

    public Label menu1;
    public Label menu2;
    public Label menu3;
    public Label menu4;
    public Label menu5;
    public Label menu6;
    public Label menu7;
    public Label menu8;
    public Label menu9;
    public Label menu10;
    public Label menu11;
    public Label menu12;

    public Label precio1;
    public Label precio2;
    public Label precio3;
    public Label precio4;
    public Label precio5;
    public Label precio6;
    public Label precio7;
    public Label precio8;
    public Label precio9;
    public Label precio10;
    public Label precio11;
    public Label precio12;

    public Button BotonDeCompra;
    public TextField precioTotal;
    public static boolean IncioSesionCliente = false;
    public Button tareaBton;
    float precioTotalCalculado = 0;
    public Button ClaroOscuro;
    public AnchorPane Fondo;

    @Override
    public void initialize(URL location, ResourceBundle resources) {


        Platform.runLater(() -> {
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);
            ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/editoscuro.png","/imgs/editclaro.png",tareaBton,30,30);
            ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/editclaro.png","/imgs/editoscuro.png",tareaBton,30,30);

        });

        // Establecer el valor inicial del Spinner
        insertarImagenes();
        InicioSesion(ControladorInicioDeSesionCliente.InicioSesionCompletado);
        cargarProductos();
        actualizarPrecioTotal();
    }

    private void cargarProductos() {
        // Nombres de los menús


        menu1.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 1));
        menu2.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 2));
        menu3.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 3));
        menu4.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 4));
        menu5.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 5));
        menu6.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 6));
        menu7.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 7));
        menu8.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 8));
        menu9.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 9));
        menu10.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 10));
        menu11.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 11));
        menu12.setText(SentenciasSql.obtenerNombreYPrecioProductos("nombre", 12));

        // Precios de los menús
        precio1.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 1)));
        precio2.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 2)));
        precio3.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 3)));
        precio4.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 4)));
        precio5.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 5)));
        precio6.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 6)));
        precio7.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 7)));
        precio8.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 8)));
        precio9.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 9)));
        precio10.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 10)));
        precio11.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 11)));
        precio12.setText(obtenerPrecioFormateado(SentenciasSql.obtenerNombreYPrecioProductos("precio", 12)));

        CargarSpinner();
    }
    private void CargarSpinner() {
        configurarSpinner(spinner1);
        configurarSpinner(spinner2);
        configurarSpinner(spinner3);
        configurarSpinner(spinner4);
        configurarSpinner(spinner5);
        configurarSpinner(spinner6);
        configurarSpinner(spinner7);
        configurarSpinner(spinner8);
        configurarSpinner(spinner9);
        configurarSpinner(spinner10);
        configurarSpinner(spinner11);
        configurarSpinner(spinner12);


        // Agregar ChangeListeners para cada Spinner
        agregarChangeListener(spinner1,precio1);
        agregarChangeListener(spinner2,precio2);
        agregarChangeListener(spinner3,precio3);
        agregarChangeListener(spinner4,precio4);
        agregarChangeListener(spinner5,precio5);
        agregarChangeListener(spinner6,precio6);
        agregarChangeListener(spinner7,precio7);
        agregarChangeListener(spinner8,precio8);
        agregarChangeListener(spinner9,precio9);
        agregarChangeListener(spinner10,precio10);
        agregarChangeListener(spinner11,precio11);
        agregarChangeListener(spinner12,precio12);
    }
    private void configurarSpinner(Spinner<Integer> spinner) {
        spinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, Integer.MAX_VALUE, 0));

        // Agregar un ChangeListener al Spinner
        spinner.valueProperty().addListener((observable, oldValue, newValue) -> {
            // Verificar si el nuevo valor es menor que 0
            if (newValue < 0) {
                // Si es menor que 0, establecer el valor del Spinner a 0
                spinner.getValueFactory().setValue(0);
            }
        });
    }
    private void agregarChangeListener(Spinner<Integer> spinner, Label precioText) {
        spinner.valueProperty().addListener((observable, oldValue, newValue) -> {
            double precioArticulo = obtenerPrecioNumerico(precioText.getText());
            double precioAnterior = oldValue * precioArticulo;
            double precioNuevo = newValue * precioArticulo;

            // Restar el precio del artículo anterior al precio total
            precioTotalCalculado -= precioAnterior;
            // Sumar el precio del artículo nuevo al precio total
            precioTotalCalculado += precioNuevo;

            // Asegurar que el precio total no sea negativo
            precioTotalCalculado = Math.max(0, precioTotalCalculado);

            // Actualizar el TextField del precio total
            precioTotal.setText(String.format("%.2f €", precioTotalCalculado));
        });
    }

    private void actualizarPrecioTotal() {
        // Calcular el precio total sumando el precio de cada artículo multiplicado por la cantidad seleccionada en su Spinner correspondiente
        precioTotalCalculado += (Integer) spinner1.getValue() * obtenerPrecioNumerico(precio1.getText());
        precioTotalCalculado += (Integer) spinner2.getValue() * obtenerPrecioNumerico(precio2.getText());
        precioTotalCalculado += (Integer) spinner3.getValue() * obtenerPrecioNumerico(precio3.getText());
        precioTotalCalculado += (Integer) spinner4.getValue() * obtenerPrecioNumerico(precio4.getText());
        precioTotalCalculado += (Integer) spinner5.getValue() * obtenerPrecioNumerico(precio5.getText());
        precioTotalCalculado += (Integer) spinner6.getValue() * obtenerPrecioNumerico(precio6.getText());
        precioTotalCalculado += (Integer) spinner7.getValue() * obtenerPrecioNumerico(precio7.getText());
        precioTotalCalculado += (Integer) spinner8.getValue() * obtenerPrecioNumerico(precio8.getText());
        precioTotalCalculado += (Integer) spinner9.getValue() * obtenerPrecioNumerico(precio9.getText());
        precioTotalCalculado += (Integer) spinner10.getValue() * obtenerPrecioNumerico(precio10.getText());
        precioTotalCalculado += (Integer) spinner11.getValue() * obtenerPrecioNumerico(precio11.getText());
        precioTotalCalculado += (Integer) spinner12.getValue() * obtenerPrecioNumerico(precio12.getText());

        // Redondear el precio total a dos decimales
        precioTotalCalculado = Math.round(precioTotalCalculado * 100) / 100f;

        // Actualizar el valor del TextField del precio total
        precioTotal.setText(String.format("%.2f €", precioTotalCalculado));
    }

    private double obtenerPrecioNumerico(String precioConSimbolo) {

        // Eliminar el símbolo "€" y los espacios en blanco, luego convertir a double
        String precioNumerico = precioConSimbolo.replaceAll("[^\\d.,]", "");
        // Reemplazar las comas por puntos para tener un formato consistente
        precioNumerico = precioNumerico.replace(',', '.');

        // Convertir a double
        double precio = Double.parseDouble(precioNumerico);
        return precio;
    }
    private String obtenerPrecioFormateado(String precioConSimbolo) {
        // Eliminar el símbolo "€" y los espacios en blanco, luego convertir a double
        String precioNumerico = precioConSimbolo.replaceAll("[^\\d.,]", "");
        // Reemplazar las comas por puntos para tener un formato consistente
        precioNumerico = precioNumerico.replace(',', '.');

        // Convertir a double
        double precio = Double.parseDouble(precioNumerico);
        System.out.println(IncioSesionCliente);
        // Aplicar descuento del 15% si IncioSesionCliente es true
        if (IncioSesionCliente) {
            precio *= 0.85; // Aplicar un descuento del 15%
        }

        // Formatear el precio con dos decimales y devolverlo como String
        return String.format("%.2f €", precio);
    }

    public static void InicioSesion(boolean cond) {
        IncioSesionCliente = cond;
    }

    public void HacerPedidoBUtton(ActionEvent actionEvent) {
        try {
            if (precioTotalCalculado > 0) {
                ControladorInicioDeSesionCliente.InicioSesionCompletado = false;
                SentenciasSql.insertarPedido(precioTotalCalculado);
                Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/Inicio.fxml", "Inicio");
                Pantallas.cerrarVentana(BotonDeCompra);
            } else {
                Pantallas.mostrarAlerta("Error", "No se ha relizado un pedido", "No puedes hacer un pedido sino vas a comprar nada");
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void insertarImagenes() {
        // Llamar al método addImage con la ruta relativa
        Pantallas.addImage(imagen1, Pantallas.conversorRutaRelativa("Ensalada.jpg"), 89, 82);
        Pantallas.addImage(imagen2, Pantallas.conversorRutaRelativa("polloParrilla.jpg"), 89, 82);
        Pantallas.addImage(imagen3, Pantallas.conversorRutaRelativa("papasFritas.jpg"), 89, 82);
        Pantallas.addImage(imagen4, Pantallas.conversorRutaRelativa("burguerClassic.png"), 89, 82);
        Pantallas.addImage(imagen5, Pantallas.conversorRutaRelativa("Cola.jpg"), 89, 82);
        Pantallas.addImage(imagen6, Pantallas.conversorRutaRelativa("hAMBURGUESA vEGANA.jpg"), 89, 85);
        Pantallas.addImage(imagen7, Pantallas.conversorRutaRelativa("pizza Margarita.jpg"), 89, 82);
        Pantallas.addImage(imagen8, Pantallas.conversorRutaRelativa("sandwich de pollo.jpg"), 89, 82);
        Pantallas.addImage(imagen9, Pantallas.conversorRutaRelativa("chocoBatido.jpg"), 89, 82);
        Pantallas.addImage(imagen10, Pantallas.conversorRutaRelativa("tartaDeManzana.jpg"), 89, 82);
        Pantallas.addImage(imagen11, Pantallas.conversorRutaRelativa("carne_asada.jpg"), 89, 82);
        Pantallas.addImage(imagen12, Pantallas.conversorRutaRelativa("Helado De Vainalla.jpg"), 89, 82);

    }

    public void llamarcambiarClaroOscuro(ActionEvent actionEvent) {

        ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/editoscuro.png","/imgs/editclaro.png",tareaBton,30,30);
        ControladorClaroOscuro.llamarcambiarClaroOscuro(ClaroOscuro,Fondo);

    }

    @FXML
    private void verCarta(ActionEvent event) {

        if (verificarCantidadCero()) {
            Pantallas.mostrarAlerta("Error", "No tienes seleccionado ningún Menú", "Debes seleccionar  al menos un plato del Menú.");
            return; // Salir del método si todas las cantidades son cero
        }
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Detalle del Pedido");

        // Configurar el contenido del diálogo
        GridPane gridPane = new GridPane();
        TableView<DetallePedido> tableView = new TableView<>();
        tableView.setEditable(false);
        tableView.setPrefWidth(260); // Establecer un ancho fijo para la tabla

        // Crear columnas para la tabla
        TableColumn<DetallePedido, String> nombreColumn = new TableColumn<>("Nombre");
        nombreColumn.setCellValueFactory(new PropertyValueFactory<>("nombre"));

        TableColumn<DetallePedido, Double> precioColumn = new TableColumn<>("Precio");
        precioColumn.setCellValueFactory(new PropertyValueFactory<>("precio"));

        // Limitar el precio a dos números decimales en la columna Precio y reemplazar puntos por comas

        precioColumn.setCellFactory(tc -> new TableCell<DetallePedido, Double>() {
            @Override
            protected void updateItem(Double item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(String.format("%.2f", item).replace('.', ','));
                }
            }
        });

        TableColumn<DetallePedido, Integer> cantidadColumn = new TableColumn<>("Cantidad");
        cantidadColumn.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

        TableColumn<DetallePedido, Double> totalColumn = new TableColumn<>("Total");
        totalColumn.setCellValueFactory(new PropertyValueFactory<>("total"));
        // Limitar el total a dos números decimales y reemplazar puntos por comas
        totalColumn.setCellFactory(tc -> new TableCell<DetallePedido, Double>() {
            @Override
            protected void updateItem(Double item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(String.format("%.2f", item).replace('.', ','));
                }
            }
        });

        tableView.getColumns().addAll(nombreColumn, precioColumn, cantidadColumn, totalColumn);

        // Obtener los datos del pedido
        ObservableList<DetallePedido> detalles = FXCollections.observableArrayList();

        // Agregar los detalles del pedido
        Pantallas.agregarDetallePedido(detalles, spinner1, precio1, menu1);
        Pantallas.agregarDetallePedido(detalles, spinner2, precio2, menu2);
        Pantallas.agregarDetallePedido(detalles, spinner3, precio3, menu3);
        Pantallas.agregarDetallePedido(detalles, spinner4, precio4, menu4);
        Pantallas.agregarDetallePedido(detalles, spinner5, precio5, menu5);
        Pantallas.agregarDetallePedido(detalles, spinner6, precio6, menu6);
        Pantallas.agregarDetallePedido(detalles, spinner7, precio7, menu7);
        Pantallas.agregarDetallePedido(detalles, spinner8, precio8, menu8);
        Pantallas.agregarDetallePedido(detalles, spinner9, precio9, menu9);
        Pantallas.agregarDetallePedido(detalles, spinner10, precio10, menu10);
        Pantallas.agregarDetallePedido(detalles, spinner11, precio11, menu11);
        Pantallas.agregarDetallePedido(detalles, spinner12, precio12, menu12);

        tableView.setItems(detalles);

        // Agregar la tabla al GridPane
        gridPane.add(tableView, 0, 0);

        dialog.getDialogPane().setContent(gridPane);

        // Verificar el estado de la variable estática nochedia y cargar el estilo correspondiente
        if (!ControladorClaroOscuro.nochedia) {
            dialog.getDialogPane().getStylesheets().add(ControladorClaroOscuro.class.getResource("/styles/style_day.css").toExternalForm());
        } else {
            dialog.getDialogPane().getStylesheets().add(ControladorClaroOscuro.class.getResource("/styles/style_night.css").toExternalForm());
        }

        // Agregar botón de cerrar
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.showAndWait();
    }

    private boolean verificarCantidadCero() {
        // Crear un array de spinners para iterar sobre ellos
        Spinner<Integer>[] spinners = new Spinner[]{
                spinner1, spinner2, spinner3, spinner4, spinner5,
                spinner6, spinner7, spinner8, spinner9, spinner10,
                spinner11, spinner12
        };

        // Iterar sobre los spinners y verificar si la cantidad es cero en todos ellos
        for (Spinner<Integer> spinner : spinners) {
            if (spinner.getValue() != 0) {
                return false; // Si encuentra al menos un spinner con cantidad distinta de cero, retorna falso
            }
        }
        return true; // Retorna verdadero si todas las cantidades son cero
    }

}
