package com.example.cynthia_burguer.Controladores;

import com.example.cynthia_burguer.Elementos.ControladorClaroOscuro;
import com.example.cynthia_burguer.Elementos.Pantallas;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;

public class ControladorClienteOadmin {
    public Button BotonClientes;
    public Button BotonAdministradores;
    public AnchorPane Fondo;
    public Button ClaroOscuro;


    @FXML
    protected void initialize() {


        Platform.runLater(() -> {
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);
            ControladorClaroOscuro.actualizarEstiloNocturno(ClaroOscuro,Fondo);

            ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/AdminA.png","/imgs/AdminB.png",BotonAdministradores,200,200);
            ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/ClienteA.png","/imgs/ClienteB.png",BotonClientes,200,200);
            ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/AdminA.png","/imgs/AdminB.png",BotonAdministradores,200,200);
            ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/ClienteA.png","/imgs/ClienteB.png",BotonClientes,200,200);

        });

    }

    public void ClientesPantalla(ActionEvent actionEvent) {
        try {
            Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/InicioDeSesionCliente.fxml","Inicio de sesión Cliente");
            Pantallas.cerrarVentana(BotonClientes);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void AdministradoresPantalla(ActionEvent actionEvent) {

        try {
            Pantallas.CambiarPantalla("/com/example/Cynthia_Burguer/InicioDeSesionAdministrador.fxml","Inicio de sesión Administrador");
            Pantallas.cerrarVentana(BotonAdministradores);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void llamarcambiarClaroOscuro(ActionEvent actionEvent) {
        ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/AdminB.png",    "/imgs/AdminA.png",BotonAdministradores,200,200);
        ControladorClaroOscuro.CambiarImagen(Fondo,"/imgs/ClienteB.png",   "/imgs/ClienteA.png",BotonClientes,200,200);

        ControladorClaroOscuro.llamarcambiarClaroOscuro(ClaroOscuro,Fondo);
    }
}
